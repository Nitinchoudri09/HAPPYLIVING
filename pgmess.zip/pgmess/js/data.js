/* Data Store for Happy Living */

// --- Persistence Helper ---
const DB = {
    init: () => {
        if (!localStorage.getItem('happyLiving_PGs')) {
            localStorage.setItem('happyLiving_PGs', JSON.stringify(PGs_Static));
        }
        if (!localStorage.getItem('happyLiving_Menu')) {
            localStorage.setItem('happyLiving_Menu', JSON.stringify(WeeklyMenu_Static));
        }
        if (!localStorage.getItem('happyLiving_Allocations')) {
            localStorage.setItem('happyLiving_Allocations', JSON.stringify(Allocations_Static));
        }
    },
    get: (key) => JSON.parse(localStorage.getItem(key)),
    set: (key, data) => localStorage.setItem(key, JSON.stringify(data)),
    updateMenu: (day, type, items) => {
        const menu = DB.get('happyLiving_Menu');
        menu[day][type] = items.split(',').map(s => s.trim());
        DB.set('happyLiving_Menu', menu);
    }
};

// --- Static Data (Initial) ---
const PGs_Static = [
    {
        id: 1,
        name: "Sunrise Residency",
        address: "12/A, North Campus Avenue, Delhi",
        sharingVariants: { 2: 8500, 3: 7500, 4: 6500 },
        rating: 4.5,
        type: "Boys",
        image: "../assets/pg_exterior.png",
        amenities: ["WiFi", "AC", "Laundry"],
        messOptions: [
            { id: 101, name: "Spicy Bites", price: 2500, rating: 4.2 },
            { id: 102, name: "Homely Meals", price: 2800, rating: 4.8 }
        ]
    },
    {
        id: 2,
        name: "Green Valley Girls PG",
        address: "Sector 45, Gurgaon",
        sharingVariants: { 2: 10500, 3: 9000, 4: 8000 },
        rating: 4.8,
        type: "Girls",
        image: "../assets/pg_interior_2.png",
        amenities: ["WiFi", "AC", "Security", "Gym"],
        messOptions: [
            { id: 103, name: "Healthy Hub", price: 3000, rating: 4.9 },
            { id: 104, name: "Mom's Kitchen", price: 2600, rating: 4.3 }
        ]
    },
    {
        id: 3,
        name: "Elite Student Housing",
        address: "Koramangala, Bangalore",
        sharingVariants: { 1: 18000, 2: 12000, 3: 10000 },
        rating: 4.6,
        type: "Co-Ed",
        image: "../assets/pg_rooftop.png",
        amenities: ["WiFi", "AC", "Gaming Zone", "Library"],
        messOptions: [{ id: 105, name: "Chef's Special", price: 3500, rating: 4.7 }]
    },
    {
        id: 4,
        name: "Comfort Zone",
        address: "Hinjewadi, Pune",
        sharingVariants: { 3: 7500, 4: 6000 },
        rating: 4.0,
        type: "Boys",
        image: "../assets/pg_room.png",
        amenities: ["WiFi", "Parking"],
        messOptions: [{ id: 106, name: "Pune Tiffin", price: 2200, rating: 4.0 }]
    },
    {
        id: 5,
        name: "Lavender Stay",
        address: "Salt Lake, Kolkata",
        sharingVariants: { 2: 7500, 3: 6500, 4: 5500 },
        rating: 4.3,
        type: "Girls",
        image: "../assets/pg_exterior.png",
        amenities: ["WiFi", "CCTV", "Garden"],
        messOptions: [{ id: 107, name: "Bengali Rasoi", price: 2400, rating: 4.5 }]
    },
    {
        id: 6,
        name: "Urban Nest",
        address: "Gachibowli, Hyderabad",
        sharingVariants: { 1: 15000, 2: 11000, 3: 9500 },
        rating: 4.7,
        type: "Co-Ed",
        image: "../assets/pg_interior_2.png",
        amenities: ["WiFi", "AC", "Gym", "Pool"],
        messOptions: [{ id: 108, name: "Hyderabadi Spice", price: 3200, rating: 4.6 }]
    },
    {
        id: 7,
        name: "Scholar's Inn",
        address: "Navrangpura, Ahmedabad",
        sharingVariants: { 3: 7000, 4: 6000, 5: 5000 },
        rating: 4.1,
        type: "Boys",
        image: "../assets/pg_room.png",
        amenities: ["WiFi", "Library"],
        messOptions: [{ id: 109, name: "Gujarati Thali", price: 2000, rating: 4.2 }]
    },
    {
        id: 8,
        name: "Blue Sky Living",
        address: "Andheri West, Mumbai",
        sharingVariants: { 2: 15000, 3: 13000, 4: 11000 },
        rating: 4.4,
        type: "Girls",
        image: "../assets/pg_rooftop.png",
        amenities: ["WiFi", "AC", "Sea View"],
        messOptions: [{ id: 110, name: "Mumbai Tiffin", price: 3500, rating: 4.3 }]
    },
    {
        id: 9,
        name: "Metro Dorms",
        address: "Anna Nagar, Chennai",
        sharingVariants: { 2: 9000, 3: 8000, 4: 7000 },
        rating: 4.2,
        type: "Boys",
        image: "../assets/pg_exterior.png",
        amenities: ["WiFi", "Power Backup"],
        messOptions: [{ id: 111, name: "South Flavors", price: 2300, rating: 4.4 }]
    },
    {
        id: 10,
        name: "The Backpackers PG",
        address: "Civil Lines, Jaipur",
        sharingVariants: { 2: 6500, 3: 5500, 4: 4500 },
        rating: 3.9,
        type: "Co-Ed",
        image: "../assets/pg_interior_2.png",
        amenities: ["WiFi", "Rooftop"],
        messOptions: [{ id: 112, name: "Rajasthani Rasoi", price: 2100, rating: 4.1 }]
    },
    {
        id: 11,
        name: "Royal Heights PG",
        address: "Bandra East, Mumbai",
        sharingVariants: { 1: 20000, 2: 14000, 3: 12000 },
        rating: 4.9,
        type: "Boys",
        image: "../assets/pg_room.png",
        amenities: ["WiFi", "AC", "Gym", "CCTV", "Laundry"],
        messOptions: [
            { id: 113, name: "Royal Kitchen", price: 3800, rating: 4.8 },
            { id: 114, name: "Coastal Delights", price: 3600, rating: 4.6 }
        ]
    },
    {
        id: 12,
        name: "Pink Petals Girls Hostel",
        address: "Indiranagar, Bangalore",
        sharingVariants: { 2: 12000, 3: 10000, 4: 8500 },
        rating: 4.7,
        type: "Girls",
        image: "../assets/pg_room.png",
        amenities: ["WiFi", "AC", "Security", "Garden", "Study Room"],
        messOptions: [
            { id: 115, name: "Garden Fresh", price: 3200, rating: 4.7 },
            { id: 116, name: "Sweet Home Mess", price: 2900, rating: 4.5 }
        ]
    },
    {
        id: 13,
        name: "Tech Hub Residency",
        address: "Whitefield, Bangalore",
        sharingVariants: { 1: 16000, 2: 11500, 3: 9500 },
        rating: 4.6,
        type: "Co-Ed",
        image: "../assets/pg_room.png",
        amenities: ["WiFi", "AC", "Gaming Zone", "Workspace", "Cafeteria"],
        messOptions: [
            { id: 117, name: "Tech Bites", price: 3400, rating: 4.6 },
            { id: 118, name: "Quick Meals", price: 2800, rating: 4.3 }
        ]
    },
    {
        id: 14,
        name: "Heritage Stay",
        address: "Old City, Hyderabad",
        sharingVariants: { 2: 8000, 3: 7000, 4: 6000 },
        rating: 4.4,
        type: "Boys",
        image: "../assets/pg_room.png",
        amenities: ["WiFi", "AC", "Library", "Parking"],
        messOptions: [
            { id: 119, name: "Nawabi Cuisine", price: 2700, rating: 4.5 },
            { id: 120, name: "Traditional Thali", price: 2400, rating: 4.2 }
        ]
    },
    {
        id: 15,
        name: "Ocean View PG",
        address: "Marine Drive, Kochi",
        sharingVariants: { 2: 11000, 3: 9500, 4: 8000 },
        rating: 4.8,
        type: "Girls",
        image: "../assets/pg_room.png",
        amenities: ["WiFi", "AC", "Sea View", "Security", "Yoga Room"],
        messOptions: [
            { id: 121, name: "Coastal Kitchen", price: 3100, rating: 4.8 },
            { id: 122, name: "Kerala Special", price: 2800, rating: 4.6 }
        ]
    },
    {
        id: 16,
        name: "Green Campus PG",
        address: "IIT Campus Road, Delhi",
        sharingVariants: { 2: 9000, 3: 8000, 4: 7000 },
        rating: 4.5,
        type: "Boys",
        image: "../assets/pg_room.png",
        amenities: ["WiFi", "AC", "Study Hall", "Sports Area"],
        messOptions: [
            { id: 123, name: "Campus Canteen", price: 2600, rating: 4.4 },
            { id: 124, name: "Student Meals", price: 2300, rating: 4.2 }
        ]
    },
    {
        id: 17,
        name: "Luxury Living PG",
        address: "Banjara Hills, Hyderabad",
        sharingVariants: { 1: 22000, 2: 16000, 3: 14000 },
        rating: 4.9,
        type: "Co-Ed",
        image: "../assets/pg_room.png",
        amenities: ["WiFi", "AC", "Pool", "Gym", "Spa", "Concierge"],
        messOptions: [
            { id: 125, name: "Fine Dining", price: 4500, rating: 4.9 },
            { id: 126, name: "Gourmet Kitchen", price: 4200, rating: 4.8 }
        ]
    },
    {
        id: 18,
        name: "Budget Stay Hostel",
        address: "MG Road, Pune",
        sharingVariants: { 3: 6000, 4: 5000, 5: 4000 },
        rating: 3.8,
        type: "Boys",
        image: "../assets/pg_room.png",
        amenities: ["WiFi", "Parking", "Common Area"],
        messOptions: [
            { id: 127, name: "Economy Meals", price: 1800, rating: 3.9 },
            { id: 128, name: "Budget Tiffin", price: 1600, rating: 3.7 }
        ]
    },
    {
        id: 19,
        name: "Serenity Girls PG",
        address: "Vastrapur, Ahmedabad",
        sharingVariants: { 2: 8500, 3: 7500, 4: 6500 },
        rating: 4.6,
        type: "Girls",
        image: "../assets/pg_room.png",
        amenities: ["WiFi", "AC", "Security", "Meditation Room", "Garden"],
        messOptions: [
            { id: 129, name: "Healthy Bites", price: 2900, rating: 4.6 },
            { id: 130, name: "Organic Kitchen", price: 3100, rating: 4.7 }
        ]
    },
    {
        id: 20,
        name: "Metro Connect PG",
        address: "Near Metro Station, Noida",
        sharingVariants: { 2: 9500, 3: 8500, 4: 7500 },
        rating: 4.5,
        type: "Co-Ed",
        image: "../assets/pg_room.png",
        amenities: ["WiFi", "AC", "Metro Access", "Shopping Mall"],
        messOptions: [
            { id: 131, name: "Metro Meals", price: 2700, rating: 4.4 },
            { id: 132, name: "Express Kitchen", price: 2500, rating: 4.3 }
        ]
    },
    {
        id: 21,
        name: "Sunset View Residency",
        address: "Panjim, Goa",
        sharingVariants: { 2: 13000, 3: 11000, 4: 9500 },
        rating: 4.7,
        type: "Co-Ed",
        image: "../assets/pg_room.png",
        amenities: ["WiFi", "AC", "Beach Access", "Rooftop", "Barbeque"],
        messOptions: [
            { id: 133, name: "Goan Flavors", price: 3300, rating: 4.7 },
            { id: 134, name: "Seafood Special", price: 3600, rating: 4.8 }
        ]
    },
    {
        id: 22,
        name: "Scholar's Den",
        address: "University Area, Chandigarh",
        sharingVariants: { 2: 7000, 3: 6000, 4: 5000 },
        rating: 4.3,
        type: "Boys",
        image: "../assets/pg_room.png",
        amenities: ["WiFi", "Library", "Study Rooms", "Quiet Zone"],
        messOptions: [
            { id: 135, name: "Study Meals", price: 2200, rating: 4.3 },
            { id: 136, name: "Brain Food", price: 2400, rating: 4.4 }
        ]
    },
    {
        id: 23,
        name: "Elite Women's Hostel",
        address: "Hitech City, Hyderabad",
        sharingVariants: { 1: 18000, 2: 13000, 3: 11000 },
        rating: 4.8,
        type: "Girls",
        image: "../assets/pg_room.png",
        amenities: ["WiFi", "AC", "Gym", "Spa", "Salon", "Security"],
        messOptions: [
            { id: 137, name: "Elite Dining", price: 4000, rating: 4.8 },
            { id: 138, name: "Premium Kitchen", price: 3800, rating: 4.7 }
        ]
    },
    {
        id: 24,
        name: "City Center PG",
        address: "Connaught Place, Delhi",
        sharingVariants: { 2: 14000, 3: 12000, 4: 10000 },
        rating: 4.6,
        type: "Co-Ed",
        image: "../assets/pg_room.png",
        amenities: ["WiFi", "AC", "Central Location", "Shopping", "Entertainment"],
        messOptions: [
            { id: 139, name: "City Meals", price: 3500, rating: 4.5 },
            { id: 140, name: "Urban Kitchen", price: 3300, rating: 4.4 }
        ]
    },
    {
        id: 25,
        name: "Peaceful Abode",
        address: "Ooty, Tamil Nadu",
        sharingVariants: { 2: 10000, 3: 8500, 4: 7000 },
        rating: 4.7,
        type: "Girls",
        image: "../assets/pg_room.png",
        amenities: ["WiFi", "Mountain View", "Garden", "Yoga Studio", "Nature Walk"],
        messOptions: [
            { id: 141, name: "Hill Station Kitchen", price: 3000, rating: 4.7 },
            { id: 142, name: "Organic Meals", price: 3200, rating: 4.8 }
        ]
    }
];

const VendorMenus = {
    101: { special: "Spicy Chicken Biryani", items: ["Chicken Curry", "Rice", "Raita", "Salad"] },
    102: { special: "Thali Special", items: ["Dal Makhani", "Paneer", "Rice", "Naan"] },
    103: { special: "Keto Salad Bowl", items: ["Grilled Chicken", "Lettuce", "Avocado", "Dressing"] },
    104: { special: "Ghar ka Khana", items: ["Aloo Gobi", "Dal Fry", "Roti", "Rice"] },
    105: { special: "Chef's Pasta", items: ["White Sauce Pasta", "Garlic Bread", "Coke"] },
    106: { special: "Misal Pav", items: ["Misal", "Pav", "Farsan", "Buttermilk"] },
    107: { special: "Fish Curry", items: ["Rohu Fish Curry", "Rice", "Bhaja"] },
    108: { special: "Hyderabadi Dum Biryani", items: ["Mutton Biryani", "Mirchi ka Salan", "Raita"] },
    109: { special: "Dhokla & Fafda", items: ["Khaman", "Kadhi", "Jalebi"] },
    110: { special: "Vada Pav Combo", items: ["2 Vada Pav", "Chutney", "Fried Chilli", "Tea"] },
    111: { special: "Dosa Platter", items: ["Masala Dosa", "Idli", "Vada", "Sambar"] },
    112: { special: "Dal Baati Churma", items: ["Dal", "Baati", "Churma", "Gatte ki Sabzi"] },
    113: { special: "Royal Thali", items: ["Butter Chicken", "Biryani", "Naan", "Raita", "Dessert"] },
    114: { special: "Coastal Fish Curry", items: ["Pomfret Fry", "Rice", "Coconut Curry", "Appam"] },
    115: { special: "Garden Fresh Salad", items: ["Quinoa Bowl", "Grilled Vegetables", "Hummus", "Fresh Juice"] },
    116: { special: "Home Style Thali", items: ["Dal Tadka", "Aloo Matar", "Roti", "Rice", "Pickle"] },
    117: { special: "Tech Special Burger", items: ["Chicken Burger", "French Fries", "Coke", "Dessert"] },
    118: { special: "Quick Wrap Combo", items: ["Chicken Wrap", "Salad", "Soup", "Juice"] },
    119: { special: "Nawabi Biryani", items: ["Mutton Biryani", "Mirchi ka Salan", "Raita", "Shahi Tukda"] },
    120: { special: "Traditional South Thali", items: ["Sambar", "Rasam", "Curry", "Rice", "Papad"] },
    121: { special: "Kerala Fish Curry", items: ["Karimeen Fry", "Rice", "Avial", "Pappadam"] },
    122: { special: "Kerala Sadya", items: ["Rice", "Sambar", "Aviyal", "Olan", "Pachadi", "Payasam"] },
    123: { special: "Campus Special Meal", items: ["Rajma Chawal", "Roti", "Salad", "Lassi"] },
    124: { special: "Student Thali", items: ["Dal", "Sabzi", "Roti", "Rice", "Sweet"] },
    125: { special: "Fine Dining Platter", items: ["Grilled Salmon", "Mashed Potatoes", "Asparagus", "Wine"] },
    126: { special: "Gourmet Pasta", items: ["Truffle Pasta", "Garlic Bread", "Caesar Salad", "Tiramisu"] },
    127: { special: "Economy Thali", items: ["Dal", "Aloo Sabzi", "Roti", "Rice"] },
    128: { special: "Budget Meal", items: ["Khichdi", "Kadhi", "Papad", "Pickle"] },
    129: { special: "Healthy Bowl", items: ["Brown Rice", "Grilled Chicken", "Steamed Veggies", "Tahini"] },
    130: { special: "Organic Thali", items: ["Organic Dal", "Farm Fresh Vegetables", "Whole Wheat Roti", "Brown Rice"] },
    131: { special: "Metro Quick Meal", items: ["Fried Rice", "Manchurian", "Soup", "Noodles"] },
    132: { special: "Express Thali", items: ["Dal Fry", "Mix Veg", "Roti", "Rice", "Salad"] },
    133: { special: "Goan Fish Curry", items: ["Kingfish Curry", "Rice", "Kokum", "Poi"] },
    134: { special: "Seafood Platter", items: ["Prawns Curry", "Fish Fry", "Rice", "Salad"] },
    135: { special: "Study Meal", items: ["Khichdi", "Kadhi", "Papad", "Buttermilk"] },
    136: { special: "Brain Booster Thali", items: ["Omega-3 Rich Fish", "Brown Rice", "Nuts", "Fruits"] },
    137: { special: "Elite Continental", items: ["Grilled Chicken", "Mashed Potatoes", "Vegetables", "Dessert"] },
    138: { special: "Premium Thali", items: ["Paneer Butter Masala", "Dal Makhani", "Naan", "Biryani", "Ice Cream"] },
    139: { special: "City Special Meal", items: ["Butter Chicken", "Naan", "Rice", "Raita", "Gulab Jamun"] },
    140: { special: "Urban Thali", items: ["Dal Makhani", "Paneer Tikka", "Roti", "Jeera Rice", "Salad"] },
    141: { special: "Hill Station Special", items: ["Mutton Curry", "Rice", "Local Vegetables", "Tea"] },
    142: { special: "Organic Farm Thali", items: ["Organic Dal", "Seasonal Vegetables", "Millet Roti", "Brown Rice", "Honey"] }
};

const WeeklyMenu_Static = {
    "Sunday": { Breakfast: ["Aloo Paratha", "Curd", "Tea"], Lunch: ["Veg Biryani", "Raita", "Papad"], Dinner: ["Paneer Butter Masala", "Naan", "Salad"] },
    "Monday": { Breakfast: ["Poha", "Sev", "Coffee"], Lunch: ["Rajma Chawal", "Jeera Aloo", "Roti"], Dinner: ["Mix Veg", "Dal Tadka", "Rice"] },
    "Tuesday": { Breakfast: ["Idli Sambar", "Chutney", "Tea"], Lunch: ["Chole Bhature", "Lassi", "Salad"], Dinner: ["Egg Curry/Paneer", "Rice", "Roti"] },
    "Wednesday": { Breakfast: ["Upma", "Coconut Chutney", "Coffee"], Lunch: ["Kadhi Pakoda", "Rice", "Bhindi Fry"], Dinner: ["Chicken Curry/Malai Kofta", "Roti", "Rice"] },
    "Thursday": { Breakfast: ["Sandwich", "Juice", "Biscuits"], Lunch: ["Dal Makhani", "Naan", "Jeera Rice"], Dinner: ["Aloo Gobi", "Dal Fry", "Roti"] },
    "Friday": { Breakfast: ["Vada Pav", "Tea", "Banana"], Lunch: ["Fried Rice", "Manchurian", "Soup"], Dinner: ["Palak Paneer", "Roti", "Pulao"] },
    "Saturday": { Breakfast: ["Puri Bhaji", "Pickle", "Tea"], Lunch: ["Khichdi", "Kadhi", "Papad"], Dinner: ["Pizza/Pasta", "Garlic Bread", "Coke"] }
};

const Allocations_Static = [
    { student: "John Doe", room: "101", pg: "Sunrise Residency", type: "2 Sharing" },
    { student: "Amit Patel", room: "101", pg: "Sunrise Residency", type: "2 Sharing" },
    { student: "Sneha Gupta", room: "204", pg: "Green Valley Girls PG", type: "3 Sharing" },
    { student: "Rahul Verma", room: "105", pg: "Comfort Zone", type: "4 Sharing" },
    { student: "Priya Singh", room: "302", pg: "Lavender Stay", type: "2 Sharing" }
];

// Initialize Data
DB.init();

// Export accessors (using var/window to be global in browser)
window.getData = {
    PGs: () => DB.get('happyLiving_PGs'),
    Menu: () => DB.get('happyLiving_Menu'),
    Allocations: () => DB.get('happyLiving_Allocations'),
    VendorMenu: (id) => VendorMenus[id] || { special: "Standard Meal", items: ["Rice", "Dal", "Veggie"] }
};

// Subscription Tiers Configuration
const SubscriptionTiers = {
    Silver: {
        name: "Silver",
        multiplier: 1.0,
        features: ["2 Meals/Day", "Basic Menu", "Standard Service"],
        color: "#94a3b8"
    },
    Gold: {
        name: "Gold",
        multiplier: 1.3,
        features: ["3 Meals/Day", "Premium Menu", "Priority Service", "Extra Snacks"],
        color: "#fbbf24"
    },
    Platinum: {
        name: "Platinum",
        multiplier: 1.6,
        features: ["3 Meals/Day", "Gourmet Menu", "VIP Service", "Unlimited Snacks", "Special Dishes"],
        color: "#8b5cf6"
    }
};

// Payment System
const PaymentSystem = {
    processPayment: (type, amount, details, email) => {
        return new Promise((resolve) => {
            // Simulate payment processing
            setTimeout(() => {
                const payment = {
                    id: Date.now(),
                    type: type, // 'PG' or 'Mess'
                    amount: amount,
                    details: details,
                    email: email,
                    status: 'Completed',
                    date: new Date().toISOString(),
                    transactionId: 'TXN' + Date.now()
                };
                
                const payments = JSON.parse(localStorage.getItem('payments') || '[]');
                payments.unshift(payment);
                localStorage.setItem('payments', JSON.stringify(payments));
                
                resolve(payment);
            }, 2000);
        });
    },
    
    getPayments: () => JSON.parse(localStorage.getItem('payments') || '[]')
};

// Notification System
const NotificationSystem = {
    notifications: [],
    
    add: (title, message, type = 'info') => {
        const notification = {
            id: Date.now(),
            title: title,
            message: message,
            type: type, // 'success', 'error', 'info', 'warning'
            read: false,
            timestamp: new Date().toISOString()
        };
        
        this.notifications.unshift(notification);
        localStorage.setItem('notifications', JSON.stringify(this.notifications));
        
        // Show browser notification if permitted
        if (Notification.permission === 'granted') {
            new Notification(title, { body: message, icon: '/assets/hero_image.png' });
        }
        
        return notification;
    },
    
    getAll: () => {
        this.notifications = JSON.parse(localStorage.getItem('notifications') || '[]');
        return this.notifications;
    },
    
    markAsRead: (id) => {
        this.notifications = this.notifications.map(n => 
            n.id === id ? { ...n, read: true } : n
        );
        localStorage.setItem('notifications', JSON.stringify(this.notifications));
    },
    
    getUnreadCount: () => {
        return this.getAll().filter(n => !n.read).length;
    },
    
    requestPermission: () => {
        if ('Notification' in window && Notification.permission === 'default') {
            Notification.requestPermission();
        }
    }
};

// Email Service (Simulated)
const EmailService = {
    sendCredentials: (email, username, password, bookingDetails) => {
        // In a real app, this would send an actual email
        // For now, we'll store it and show it to the user
        const emailData = {
            to: email,
            subject: 'Welcome to Happy Living PG - Your Login Credentials',
            body: `
Dear Student,

Welcome to Happy Living PG!

Your booking has been confirmed. Here are your login credentials:

Username: ${username}
Password: ${password}

Booking Details:
${bookingDetails}

Please keep these credentials safe. You can use them to login to your student portal.

Best regards,
Happy Living PG Team
            `,
            sent: true,
            timestamp: new Date().toISOString()
        };
        
        const emails = JSON.parse(localStorage.getItem('sentEmails') || '[]');
        emails.unshift(emailData);
        localStorage.setItem('sentEmails', JSON.stringify(emails));
        
        // Show confirmation
        console.log('Email sent to:', email);
        return emailData;
    }
};

// Booking System
const BookingSystem = {
    generateCredentials: (email) => {
        // Generate username from email
        const username = email.split('@')[0] + Math.floor(Math.random() * 1000);
        // Generate password
        const password = 'HL' + Math.random().toString(36).substring(2, 10).toUpperCase() + Math.floor(Math.random() * 100);
        return { username, password };
    },
    
    bookPG: async (pgId, sharing, rent, email, studentName, phone) => {
        const PGs = getData.PGs();
        const pg = PGs.find(p => p.id === pgId);
        
        if (!pg) throw new Error('PG not found');
        
        // Process payment
        const payment = await PaymentSystem.processPayment(
            'PG',
            rent,
            `PG Booking: ${pg.name} (${sharing}-Sharing)`,
            email
        );
        
        // Generate credentials
        const { username, password } = this.generateCredentials(email);
        
        // Create booking
        const booking = {
            id: Date.now(),
            type: 'PG',
            pgId: pgId,
            pgName: pg.name,
            sharing: sharing,
            rent: rent,
            studentName: studentName,
            email: email,
            phone: phone,
            username: username,
            password: password,
            status: 'Confirmed',
            bookingDate: new Date().toISOString(),
            paymentId: payment.id
        };
        
        const bookings = JSON.parse(localStorage.getItem('bookings') || '[]');
        bookings.unshift(booking);
        localStorage.setItem('bookings', JSON.stringify(bookings));
        
        // Add to allocations
        const allocations = getData.Allocations();
        allocations.push({
            student: studentName,
            room: `Room-${Math.floor(Math.random() * 500)}`,
            pg: pg.name,
            type: `${sharing} Sharing`
        });
        DB.set('happyLiving_Allocations', allocations);
        
        // Send email with credentials
        const bookingDetails = `
PG Name: ${pg.name}
Room Type: ${sharing}-Sharing
Monthly Rent: ₹${rent}
Booking Date: ${new Date().toLocaleDateString()}
        `;
        
        EmailService.sendCredentials(email, username, password, bookingDetails);
        
        // Add notification
        NotificationSystem.add(
            'PG Booking Confirmed!',
            `Your booking at ${pg.name} is confirmed. Check your email for login credentials.`,
            'success'
        );
        
        return booking;
    },
    
    subscribeMess: async (messId, messName, basePrice, tier, email, studentName, phone, pgName) => {
        const tierInfo = SubscriptionTiers[tier];
        const finalPrice = Math.round(basePrice * tierInfo.multiplier);
        
        // Process payment
        const payment = await PaymentSystem.processPayment(
            'Mess',
            finalPrice,
            `Mess Subscription: ${messName} (${tier} Plan)`,
            email
        );
        
        // Create subscription
        const subscription = {
            id: Date.now(),
            type: 'Mess',
            messId: messId,
            messName: messName,
            tier: tier,
            basePrice: basePrice,
            finalPrice: finalPrice,
            studentName: studentName,
            email: email,
            phone: phone,
            pgName: pgName,
            status: 'Active',
            startDate: new Date().toISOString(),
            paymentId: payment.id
        };
        
        const subscriptions = JSON.parse(localStorage.getItem('messSubscriptions') || '[]');
        subscriptions.unshift(subscription);
        localStorage.setItem('messSubscriptions', JSON.stringify(subscriptions));
        
        // Add notification
        NotificationSystem.add(
            'Mess Subscription Activated!',
            `Your ${tier} subscription to ${messName} is now active.`,
            'success'
        );
        
        return subscription;
    },
    
    getBookings: () => JSON.parse(localStorage.getItem('bookings') || '[]'),
    getSubscriptions: () => JSON.parse(localStorage.getItem('messSubscriptions') || '[]')
};

// Request Handling
const RequestSystem = {
    addRequest: (type, details) => {
        const requests = JSON.parse(localStorage.getItem('adminRequests') || '[]');
        const newRequest = {
            id: Date.now(),
            type: type,
            studentName: 'Student User', // Mock name
            details: details,
            status: 'Pending',
            date: new Date().toLocaleDateString()
        };
        requests.unshift(newRequest);
        localStorage.setItem('adminRequests', JSON.stringify(requests));
        alert(`${type} request sent successfully!`);
    },

    getRequests: () => JSON.parse(localStorage.getItem('adminRequests') || '[]'),

    updateRequestStatus: (id, status) => {
        let requests = JSON.parse(localStorage.getItem('adminRequests') || '[]');
        requests = requests.map(req => req.id === id ? { ...req, status: status } : req);
        localStorage.setItem('adminRequests', JSON.stringify(requests));
        return requests;
    }
};

// Export systems
window.PaymentSystem = PaymentSystem;
window.NotificationSystem = NotificationSystem;
window.EmailService = EmailService;
window.BookingSystem = BookingSystem;
window.SubscriptionTiers = SubscriptionTiers;
