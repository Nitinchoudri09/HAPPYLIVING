document.addEventListener('DOMContentLoaded', () => {
    // Scroll Animation Observer
    const observerOptions = {
        threshold: 0.1
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate-slide-up');
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);

    document.querySelectorAll('.animate-on-scroll').forEach(el => {
        observer.observe(el);
    });
});

// Mock Authentication Helper
const Auth = {
    login: (role, username, password) => {
        // Simple mock validation
        if (role === 'admin' && username === 'admin' && password === 'admin123') {
            localStorage.setItem('user', JSON.stringify({ role: 'admin', name: 'Admin User' }));
            return true;
        }
        if (role === 'student' && username === 'student' && password === 'student123') {
            localStorage.setItem('user', JSON.stringify({ role: 'student', name: 'John Doe', room: '101' }));
            return true;
        }
        return false;
    },
    
    logout: () => {
        localStorage.removeItem('user');
        window.location.href = '../index.html';
    },

    checkAuth: (requiredRole) => {
        const user = JSON.parse(localStorage.getItem('user'));
        if (!user || user.role !== requiredRole) {
            window.location.href = '../index.html';
        }
        return user;
    }
};
